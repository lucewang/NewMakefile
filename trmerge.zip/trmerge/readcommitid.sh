#!/bin/bash

if [ "$#" -ne 3 ]; then
    echo "Usage: $0 <please input cfg file name> <please input default commitid> <please input default reponame>"
    exit 1
fi

config_file="$1"
commit_id="$2"
nokia_repo="$3"

if [ -f "$config_file" ]; then
    while IFS='=' read -r key value; do
        if [ "$key" = "NOKIA_REVISION" ]; then
            commit_id="$value"
	elif [ "$key" = "NOKIA_REPO" ]; then
            nokia_repo="$value"
        fi
    done < "$config_file"
fi

echo "$commit_id" "$nokia_repo"

