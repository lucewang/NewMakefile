#ifndef __TRPROXY_FWA__
#define __TRPROXY_FWA__

void register_fwa_product();
void fwa_init();
void publish_CPEMethod_message();

#endif