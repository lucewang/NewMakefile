#ifndef __TRPROXY__
#define __TRPROXY__

#include <stdio.h>

//define FWA callback function
void handle_transferCompleteEvent();

// Function pointer types for individual behaviors
typedef void (*FuncProxyInitPtr)(void);
typedef void (*FuncCPEMethodPtr)(void);
typedef void (*FuncCfgmgrEventPtr)(void);
typedef void (*FuncCommonHandlerPtr)(void);

// Product structure to hold product-specific data
typedef struct {
    //ProductType type;
    FuncProxyInitPtr proxy_init;
    FuncCPEMethodPtr handle_cpe_method;
    FuncCfgmgrEventPtr handle_cfgmgr_event;
    FuncCommonHandlerPtr common_handler;
} Product;

#endif