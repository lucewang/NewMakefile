#ifndef __TRPROXY_ONT__
#define __TRPROXY_ONT__

void ont_init();
void register_ont_product();

#endif