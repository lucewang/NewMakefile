#ifndef __TRPROXY_COMMON__
#define __TRPROXY_COMMON__

void common_handler();

#endif