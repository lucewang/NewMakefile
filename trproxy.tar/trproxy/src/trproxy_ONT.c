#include "trproxy_ONT.h"
#include "trproxy_common.h"
#include "trproxy.h"

extern Product* g_registeredProduct;

// ONT product definition
Product ONT_product = {
    //.type = PRODUCT_ONT,
    .proxy_init = ont_init,
    .handle_cpe_method = NULL,
    .handle_cfgmgr_event = NULL,
    .common_handler = common_handler
};

void register_ont_product() {
    g_registeredProduct = &ONT_product;
}

void ont_init()
{
    printf("Enter ont_init function!\n");
}