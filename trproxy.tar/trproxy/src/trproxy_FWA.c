#include "trproxy_FWA.h"
#include "trproxy_common.h"
#include "trproxy.h"

extern Product* g_registeredProduct;

//FWA product definition
Product FWA_product = {
    //.type = PRODUCT_FWA,
    .proxy_init = fwa_init,
    .handle_cpe_method = publish_CPEMethod_message,
    .handle_cfgmgr_event = NULL,
    .common_handler = common_handler
};

void register_fwa_product() {
    g_registeredProduct = &FWA_product;
}

void fwa_init()
{
    printf("Enter fwa_init function!\n");
    printf("Call mqtt_init function!\n");
}

void publish_CPEMethod_message()
{
    printf("Enter publish_CPEMethod_message function!\n");
    handle_transferCompleteEvent();
}
