#include "trproxy_common.h"
#include "trproxy.h"

void common_handler()
{
    printf("Enter common_handler function!\n");
}