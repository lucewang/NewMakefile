/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include "trproxy_common.h"
#include "trproxy_FWA.h"
#include "trproxy_ONT.h"
#include "trproxy.h"

Product* g_registeredProduct = NULL;

void handle_transferCompleteEvent()
{
    printf("Enter handle_transferCompleteEvent callback function!\n");
}

int main()
{
    // Register Product FWA
    register_fwa_product();
    g_registeredProduct->proxy_init();
    g_registeredProduct->handle_cpe_method();
    g_registeredProduct->common_handler();
    
    // Register Product ONT
    register_ont_product();
    g_registeredProduct->proxy_init();
    g_registeredProduct->common_handler();
    
    return 0;
}